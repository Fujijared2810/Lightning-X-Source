﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Lightnin_X
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Thread CheckUpdates;

        private WebClient wc = new WebClient();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
			if (!Directory.Exists("bin"))
			{
				Directory.CreateDirectory("bin");
			}
			if (!Directory.Exists("scripts"))
			{
				Directory.CreateDirectory("scripts");
			}
			if (!Directory.Exists("workspace"))
			{
				Directory.CreateDirectory("workspace");
			}
			if (!Directory.Exists("autoexec"))
			{
				Directory.CreateDirectory("autoexec");
			}
			if (!File.Exists("bin\\rbxfpsunlocker.exe"))
            {
				wc.DownloadFile("https://cdn.discordapp.com/attachments/856792157741121566/876118617064882206/rblxfpsunlocker.exe", "bin\\rbxfpsunlocker.exe");
            }
			if (!File.Exists("ICSharpCode.AvalonEdit.dll"))
            {
				wc.DownloadFile("https://cdn.discordapp.com/attachments/856792157741121566/871655873880137738/ICSharpCode.AvalonEdit.dll", "ICSharpCode.AvalonEdit.dll");
            }
			if (!File.Exists("workspace\\PuppyMilkV3.exe"))
            {
				wc.DownloadFile("https://cdn.discordapp.com/attachments/856792157741121566/870918198000746496/PuppyMilkV3.exe", "workspace\\PuppyMilkV3.exe");
            }
			CheckUpdates = new Thread(CheckUpdates_DoWork);
			CheckUpdates.Start();
		}
		private void ChangeStatus(string status, int bar = 0)
		{
			base.Dispatcher.Invoke(delegate
			{
				Label.Content = status;
				Bar.Value += bar;
			});
		}

		private void CheckUpdates_DoWork()
		{
			ChangeStatus("Checking For Updates...");
			if (!File.Exists("bin\\Lua.xshd"))
			{
				wc.DownloadFile("https://ryos.best/api/Lua.xshd", "bin\\Lua.xshd");
			}
			string text = wc.DownloadString("https://raw.githubusercontent.com/GreenMs02/Electron/master/Games.json");
			bool flag = false;
			bool num = CheckDllUpdate();
			if (num)
			{
				ChangeStatus("Downloading DLL...", 50);
				DownloadDLL();
			}
			if (CheckSafeInjector())
			{
				ESettings.NormalInjection = false;
				ChangeStatus("Downloading Injector...", 50);
				DownloadSafeInjector();
			}
			if (!num && !flag)
			{
				ChangeStatus("Success", 100);
			}
			else
			{
				ChangeStatus("Success");
			}
			Thread.Sleep(1000);
			base.Dispatcher.Invoke(delegate
			{
				MainExploit mainExploit = new MainExploit();
				mainExploit.Show();
				this.Hide();
			});
			CheckUpdates.Abort();
		}

		private bool CheckDllUpdate()
		{
			string[] array = wc.DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (!File.Exists("bin\\version"))
			{
				File.WriteAllText("bin\\version", "0");
			}
			else if (array[0] != string.Empty && File.ReadAllText("bin\\version") != array[0])
			{
				File.WriteAllText("bin\\version", array[0]);
				return true;
			}
			return !File.Exists("ElectronDLL.dll");
		}

		private bool CheckSafeInjector()
		{
			string[] array = wc.DownloadString("https://ryos.best/api/edat2.txt").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (array[0].Contains("false"))
			{
				return false;
			}
			if (!File.Exists("bin\\versionc"))
			{
				File.WriteAllText("bin\\versionc", "0");
			}
			else if (array[1] != string.Empty && File.ReadAllText("bin\\versionc") != array[1])
			{
				File.WriteAllText("bin\\versionc", array[1]);
				return true;
			}
			ESettings.NormalInjection = false;
			return File.Exists("bin\\ElectronInjector.exe");
		}

		private bool DownloadSafeInjector()
		{
			string[] array = wc.DownloadString("https://ryos.best/api/edat2.txt").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			if (!File.Exists("bin\\msvcp140.dll"))
			{
				wc.DownloadFile("https://cdn.discordapp.com/attachments/760412369854922762/800014781368238100/msvcp140.dll", "bin\\msvcp140.dll");
			}
			if (!File.Exists("bin\\vcruntime140.dll"))
			{
				wc.DownloadFile("https://cdn.discordapp.com/attachments/760412369854922762/800014790104973402/vcruntime140.dll", "bin\\vcruntime140.dll");
			}
			wc.DownloadFile(array[2], "bin\\ElectronInjector.exe");
			return File.Exists("bin\\ElectronInjector.exe");
		}

		private bool DownloadDLL()
		{
			string[] array = wc.DownloadString("https://ryos.best/api/update.jit").Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			wc.DownloadFile(array[1], "ElectronDLL.dll");
			return File.Exists("ElectronDLL.dll");
		}

        private void Button_Click(object sender, RoutedEventArgs e)
        {
			Environment.Exit(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
			WindowState = WindowState.Minimized;
        }

        private void Mini_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
			DragMove();
        }
    }
}
