﻿
using System;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

internal class Exec
{
	public static void ExecuteScript(string Script)
	{
		if (namedPipeExist("EPipe"))
		{
			NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", "EPipe", PipeDirection.Out);
			namedPipeClientStream.Connect();
			using (StreamWriter streamWriter = new StreamWriter(namedPipeClientStream, Encoding.Default, 999999))
			{
				streamWriter.Write(Script);
				streamWriter.Dispose();
			}
			namedPipeClientStream.Dispose();
		}
		else if (File.Exists("ElectronDLL.dll"))
		{
			MessageBox.Show("Please attach!", "NamedPipeDoesntExist", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		else
		{
			MessageBox.Show("Please turn off your antivirus!", "DLLDoesntExist", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	public static bool namedPipeExist(string pipeName)
	{
		try
		{
			if (!WaitNamedPipe(Path.GetFullPath($"\\\\.\\pipe\\{pipeName}"), 0))
			{
				switch (Marshal.GetLastWin32Error())
				{
					case 0:
						return false;
					case 2:
						return false;
				}
			}
			return true;
		}
		catch (Exception)
		{
			return false;
		}
	}

	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern bool WaitNamedPipe(string name, int timeout);
}
