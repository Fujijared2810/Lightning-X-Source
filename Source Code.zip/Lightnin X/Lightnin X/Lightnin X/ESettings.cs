﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lightnin_X
{
	internal class ESettings
	{
		internal static bool NormalInjection = true;

		internal static bool RPC = true;
	}
}
